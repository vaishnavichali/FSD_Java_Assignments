package com.ibm.bank2.dao;


import java.util.ArrayList;

import com.ibm.bank2.bean.Customer;





public interface DaoInterface {

	boolean createCustomer(Customer customer);

	
	
	long checkBalance(String accountNumber);
	String deposit(String accountNumber, long depositAmount);
	String withdraw(String accountNumber, long withdrawAmount);

	String printTransactions(String accountNumber);
	
	String transfer(String sourceAccountNumber, String targetAccountNumber, long transferAmount);


}
