package com.ibm.bank2.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import com.ibm.bank2.bean.Customer;



public class DaoClass implements DaoInterface {

	public static Connection conn = null;

	public DaoClass() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bankdatabase", "root",
					"");
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}

	}

	public boolean createCustomer(Customer customer) {
		
		try {
			
            
			PreparedStatement stmt = conn.prepareStatement(
					"insert into customer(Name, AccountNumber, Balance) values(?,?,? )");
			
			stmt.setString(1, customer.getName());
			stmt.setString(2, customer.getAccountNumber());
			stmt.setLong(3, customer.getBalance());
			if (stmt.executeUpdate() > 0) {
				Date d=new Date();
			String	transaction = "Your account has been created on " +d;
	
				
				stmt = conn.prepareStatement(
						"update customer set Transactions=? where AccountNumber=?");
				stmt.setString(1, transaction);
				stmt.setString(2, customer.getAccountNumber());
				
				stmt.executeUpdate();
				
				return true;
			} else {
				
				return false;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return true;
	}

	
public long checkBalance(String accountNumber) {
		
		long balance = 0;
		try {
          			PreparedStatement stmt = conn
					.prepareStatement("select Balance from customer where AccountNumber=?");
			
			
			stmt.setString(1, accountNumber);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				balance = rs.getLong("Balance");
			}
			

		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return balance;
	}
public String deposit(String accountNumber, long depositAmount) {
	String transaction="";
try {

	PreparedStatement ps = conn.prepareStatement(
			"update customer set Balance=Balance+? where AccountNumber=?");
	ps.setLong(1, depositAmount);
	ps.setString(2, accountNumber);


	if (ps.executeUpdate() > 0) {
		ps = conn.prepareStatement("select Transactions from customer where AccountNumber=?");
		ps.setString(1, accountNumber);
		ResultSet rs = ps.executeQuery();
		if (rs.next()) {
			transaction = rs.getString("Transactions");
		}
		transaction = transaction + ", " + depositAmount + " was deposited on " + (new java.util.Date());
		
		ps = conn.prepareStatement("update customer set Transactions='" + transaction + "' where AccountNumber='"+ accountNumber + "'");
		ps.executeUpdate();
		
	

	}

} catch (SQLException e) {
	
	e.printStackTrace();
}
return depositAmount + " was deposited on " + (new java.util.Date());
}
public String withdraw(String accountNumber, long withdrawAmount) {
	
	String transaction="";
	try {

		PreparedStatement ps = conn.prepareStatement(
				"update customer set Balance=Balance-? where AccountNumber=?");
		ps.setLong(1, withdrawAmount);
		ps.setString(2, accountNumber);


		if (ps.executeUpdate() > 0) {
			ps = conn.prepareStatement("select Transactions from customer where AccountNumber=?");
			ps.setString(1, accountNumber);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				transaction = rs.getString("Transactions");
			}
			transaction = transaction + ", " + withdrawAmount + " was withdrawn on " + (new java.util.Date());
			
			ps = conn.prepareStatement("update customer set Transactions='" + transaction + "' where AccountNumber='"+ accountNumber + "'");
			ps.executeUpdate();
		}

	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	return withdrawAmount + " was withdrawn on " + (new java.util.Date());
}


public String printTransactions(String accountNumber) {
	String transactions="";
	try {
		PreparedStatement ps1 = conn.prepareStatement(
				"select transactions from customer where accountNumber=?");
		ps1.setString(1, accountNumber);
		ResultSet rs = ps1.executeQuery();

			while (rs.next()) {
				transactions = rs.getString("Transactions");
			}
			return transactions;
		} catch (SQLException e) {
			e.printStackTrace();
			return "Issues while trying to print transactions";
		}
	} 
	





public String transfer(String sourceAccountNumber, String targetAccountNumber, long transferAmount) {
	String showTransferMsg="";
	String transaction="";
	try {
		PreparedStatement ps = conn
				.prepareStatement("select * from customer where AccountNumber=?");
		ps.setString(1, targetAccountNumber);
		ResultSet result_acc=ps.executeQuery();
		if(result_acc.next()) {

		PreparedStatement ps2 = conn
				.prepareStatement("select Balance from customer where AccountNumber=?");
		
		
		ps2.setString(1, sourceAccountNumber);
		ResultSet rs = ps2.executeQuery();
		if (rs.next()) {
			int initialBal = rs.getInt("Balance");
			if ((initialBal > transferAmount) || (initialBal - transferAmount) > 0) {
				PreparedStatement ps3 = conn.prepareStatement(
						"update customer set Balance=Balance-? where AccountNumber=?");
				PreparedStatement receiver = conn
						.prepareStatement("update customer set Balance=Balance+? where AccountNumber=?");
				ps3.setLong(1, transferAmount);
				ps3.setString(2, sourceAccountNumber);
				receiver.setLong(1, transferAmount);
				receiver.setString(2, targetAccountNumber);
				receiver.executeUpdate();
				if (ps3.executeUpdate() > 0) {
					
					ps = conn.prepareStatement("select Transactions from customer where AccountNumber = '" + sourceAccountNumber + "'");
					rs = ps.executeQuery();
					while (rs.next()) {
						transaction = rs.getString("Transactions");
					}
					transaction = transaction + ", " + transferAmount + " was transferred on "
							+ (new java.util.Date()) + "to account number " + targetAccountNumber;
					ps = conn.prepareStatement("update customer set Transactions='" + transaction + "' where AccountNumber='"
							+ sourceAccountNumber + "'");
					ps.executeUpdate();
					
					ps = conn.prepareStatement("select Transactions from customer where AccountNumber = '" + targetAccountNumber + "'");
					rs = ps.executeQuery();
					while (rs.next()) {
						transaction = rs.getString("Transactions");
					}
					transaction = transaction + ", " + transferAmount + " was recieved on "
							+ (new java.util.Date()) + "from account number " + sourceAccountNumber;
					ps = conn.prepareStatement("update customer set Transactions='" + transaction + "' where AccountNumber='"
							+ targetAccountNumber + "'");
					ps.executeUpdate();
					
					
				}
			} else {
				
				showTransferMsg="Cannot Transfer";
			}
		}
		}else {
			showTransferMsg="Receiver account does not exist!!";
			
		}
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	return transferAmount+ "was transferred to "+targetAccountNumber+" from "+sourceAccountNumber+" on "+(new java.util.Date());
}
}

