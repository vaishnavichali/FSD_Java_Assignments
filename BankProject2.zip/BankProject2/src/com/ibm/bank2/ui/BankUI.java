package com.ibm.bank2.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.bank2.services.ServicesClass;
import com.ibm.bank2.services.ServicesInterface;

@WebServlet(urlPatterns= {
		"/create","/checkbalance","/deposit","/withdraw","/exit","/transfer","/transactions"
		})
public class BankUI extends HttpServlet {
	 ServicesInterface service;
 public BankUI() {
       
    }

	
	public void init() throws ServletException {

		service=new ServicesClass();
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		String path=request.getServletPath();
	
		PrintWriter pw=response.getWriter();
		boolean returnValue=false;
		long balance=0;
		String transactions="";
		String deposit_message=null;
		Object session=request.getSession().getAttribute("accountNumber");
		
		switch(path) {
		
			
		case "/create":
			
			returnValue=service.createCustomer(request, response);
			if(returnValue) {
				pw.println("Successfully created new account");
				
			}
			else {
				pw.println("Could not create new account");
				
			}
			
			
			break;
		
		case "/checkbalance":

			//if(session!=null) {
			balance=service.checkBalance(request, response);
			if(balance!=0)
				pw.println("<p>Your current balance is </+p>"+balance);
			else
				pw.println("Could not retrive data");
			
			break;
	
		case "/exit":
			/*if(session!=null) {
				request.getSession().invalidate();
				pw.println("Thank you...");*/
				//request.getRequestDispatcher("login.jsp").include(request,response);
			   System.exit(0);
			/*
			 * } else { pw.println("Some issue");
			 * //request.getRequestDispatcher("index.jsp").include(request,response); }
			 * break;
			 */
		case "/deposit":
			//  if(session!=null) {
			 deposit_message=service.deposit(request, response);
			
			//request.getRequestDispatcher("balance").forward(request,response);	
			//pw.println("<br>"+deposit_message);
			//}
			//else {
			//	pw.println("Some issue");
				//request.getRequestDispatcher("index.jsp").include(request,response);
		//	}
			if(deposit_message!=null)
				pw.println(deposit_message);
			else
				pw.println("Could not deposit the amount");
			
			
			break;
		case "/withdraw":
			//if(session!=null) {
			String withdraw_message=service.withdraw(request, response);
			if(withdraw_message!=null)
				pw.println(withdraw_message);
			else
				pw.println("Could not deposit the amount");
			
			//request.getRequestDispatcher("balance").forward(request,response);	
		//	}
		//	else {
		//		pw.println("Some issue");
				//request.getRequestDispatcher("index.jsp").include(request,response);
		//	}
			//pw.println("<br>"+withdraw_message);
			break;
			
		case "/transfer":
			//if(session!=null) {
			String transfer_message=service.transfer(request, response);
			if(transfer_message!=null)
				pw.println(transfer_message);
			else
				pw.println("Could not deposit the amount");
			
			//request.getRequestDispatcher("balance").forward(request,response);
			//}
			//else {
			//	pw.println("Some issue");
				//request.getRequestDispatcher("index.jsp").include(request,response);
			//}
			break;
			
		case "/transactions":
			//if(session!=null) {
			transactions = service.printTransactions(request,response);
		//	request.getRequestDispatcher("printTransactions.jsp").forward(request,response);
		//	}
		//	else {
		//		pw.println("Some issues");
				//request.getRequestDispatcher("index.jsp").include(request,response);
		//	}
		StringTokenizer st = new StringTokenizer(transactions, ",");	
		while (st.hasMoreTokens()) {  
		        pw.println(st.nextToken()+"<br>");  
		     }  
			
			break;
			
		}			
		
		
}	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
