package com.ibm.bank2.bean;

public class Customer {
	private String name;
	private String accountNumber;
	private long balance;
	
	public Customer(String name,String accountNumber,long balance )
	{
		this.name=name;
		this.accountNumber=accountNumber;
		this.balance=balance;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	


}

