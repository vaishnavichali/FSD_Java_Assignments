package com.ibm.bank2.services;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface ServicesInterface {

	
	boolean createCustomer(HttpServletRequest request,HttpServletResponse response);

	
	long checkBalance(HttpServletRequest request,HttpServletResponse response);
	String deposit(HttpServletRequest request,HttpServletResponse response);
	String withdraw(HttpServletRequest request,HttpServletResponse response);
		String transfer(HttpServletRequest request,HttpServletResponse response);

	String printTransactions(HttpServletRequest request,HttpServletResponse response);
	

}

