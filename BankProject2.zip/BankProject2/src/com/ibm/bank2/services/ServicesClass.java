package com.ibm.bank2.services;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ibm.bank2.bean.Customer;
import com.ibm.bank2.dao.DaoClass;


public class ServicesClass implements  ServicesInterface {
	DaoClass dao = new DaoClass();
	Customer customer;

	public boolean createCustomer(HttpServletRequest request,HttpServletResponse response) {
		
		
		String name=request.getParameter("name");
		String accountNumber=request.getParameter("accno");
		long balance=Long.parseLong(request.getParameter("balance"));
		customer=new Customer( name, accountNumber, balance);
		
		return dao.createCustomer(customer);

	}

	

	public long checkBalance(HttpServletRequest request,HttpServletResponse response) {
		//HttpSession session=request.getSession();
		String accno = request.getParameter("accno");

		return dao.checkBalance(accno);
	}

	public String deposit(HttpServletRequest request,HttpServletResponse response) {
		
		//String accno=(String)request.getSession().getAttribute("accno");
		String accno = request.getParameter("accno");
		long money=Long.parseLong(request.getParameter("balance"));
		return dao.deposit(accno, money);
	}

	public String withdraw(HttpServletRequest request,HttpServletResponse response) {
		
		String accno = request.getParameter("accno");
		long money=Long.parseLong(request.getParameter("balance"));

		return dao.withdraw(accno, money);

	}

	public String printTransactions(HttpServletRequest request,HttpServletResponse response) {
		//String accno=(String)request.getSession().getAttribute("accno");
		String accno = request.getParameter("accno");
		//ArrayList<String> arr= dao.printTransactions(accno);
		//request.getSession().setAttribute("transactions",arr );
		return dao.printTransactions(accno);
	}

	

	public String transfer(HttpServletRequest request,HttpServletResponse response) {
		String sourceAccno=request.getParameter("source_accno");
		String targetAccno=request.getParameter("target_accno");
		long money=Long.parseLong(request.getParameter("balance"));
		return dao.transfer(sourceAccno, targetAccno, money);

	}

	
}
