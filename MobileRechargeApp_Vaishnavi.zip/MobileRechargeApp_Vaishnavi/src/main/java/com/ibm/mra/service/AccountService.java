package com.ibm.mra.service;

import com.ibm.mra.beans.Account;

public interface AccountService {
  Account getAccountDetails(String mobileNumber);
  int rechargeAccount(String mobileNumber, double rechargeAmount);
  public boolean validateMobileNumber(String mobileNumber);
}
