package com.ibm.mra.ui;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ibm.mra.beans.Account;
import com.ibm.mra.service.AccountServiceImpl;

public class MainUI {
	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("appContext.xml");
		Scanner scan = new Scanner(System.in);
		Account acc = context.getBean("account", Account.class);
		int choice, returnValue;
		double amount;
		String mobileNumber;
		AccountServiceImpl service = context.getBean("myService", AccountServiceImpl.class);
		while (true) {
			System.out.println("MENU");
			System.out.println("1. BALANCE ENQUIRY");
			System.out.println("2. RECHARGE ACCOUNT");
			System.out.println("3. EXIT");
			System.out.println("Enter your choice :");
			choice = scan.nextInt();
			scan.nextLine();
			switch (choice) {
			case 1:
				System.out.println("Enter mobile number :");
				mobileNumber = scan.nextLine();
				if(!service.validateMobileNumber(mobileNumber))
				{
					System.out.println("Please enter valid mobile number");
					break;
				}
				acc = service.getAccountDetails(mobileNumber);
				if(acc!=null)
				System.out.println("Your current balance is:" + acc.getAccountBalance());
				else
					System.out.println("The account with this mobile number does not exist");
				break;

			case 2: System.out.println("Enter mobile number :");
			        mobileNumber = scan.nextLine();
			        if(!service.validateMobileNumber(mobileNumber))
					{
						System.out.println("Please enter valid mobile number");
						break;
					}
			        acc = service.getAccountDetails(mobileNumber);
			        if(acc==null)
					{
					    System.out.println("The account with this mobile number does not exist");
						break;
					}
			        System.out.println("Enter recharge amount :");
			        amount = scan.nextDouble();
			        returnValue = service.rechargeAccount(mobileNumber, amount);
			        if(returnValue > 0)
			        {
			        	System.out.println("Your account recharged successfully");
			        	System.out.println("Hello "+acc.getCustomerName()+", Available balance is Rs."+acc.getAccountBalance());
			        }
			        else
			        	System.out.println("Could not recharge");
			        break;
			        
			        
			case 3:
				System.out.println("Thank you....");
				scan.close();
				context.close();
				System.exit(0);

			default:
				System.out.println("Invalid choice");
				break;
			}

		}

	}
}
