package com.ibm.mra.service;

import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.mra.beans.Account;
import com.ibm.mra.dao.AccountDaoImpl;

@Service("myService")
public class AccountServiceImpl implements AccountService {
	
	
	 @Autowired
	 AccountDaoImpl dao;

	public Account getAccountDetails(String mobileNumber) 
	{
		
		return dao.getAccountDetails(mobileNumber);
	}

	public int rechargeAccount(String mobileNumber, double rechargeAmount) {
       

		return dao.rechargeAccount(mobileNumber, rechargeAmount);
	}
	

	public boolean validateMobileNumber(String mobileNumber) {
		
		return Pattern.matches("^[6-9]\\d{9}$", mobileNumber);
	}

}
