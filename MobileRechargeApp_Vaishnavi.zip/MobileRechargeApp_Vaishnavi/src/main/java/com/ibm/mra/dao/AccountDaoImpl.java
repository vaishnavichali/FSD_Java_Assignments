package com.ibm.mra.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ibm.mra.beans.Account;

@Repository("dbConnection")
public class AccountDaoImpl implements AccountDao{
	
	NamedParameterJdbcTemplate namedTemplate;
	
	DataSource dataSource;
    

	public DataSource getDataSource() {
		return dataSource;
	}
    
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		this.namedTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	public Account getAccountDetails(String mobileNumber) {
		try
		{
		String query = "select * from user_details where mobileNumber=:mobile";
		return namedTemplate.queryForObject(query,new MapSqlParameterSource("mobile", mobileNumber) ,
				new AccountMapper());
		}
		catch(EmptyResultDataAccessException e)
		{
			return null;
		}
	}

	public int rechargeAccount(String mobileNumber, double rechargeAmount) {
		String query = "update user_details set accountBalance = accountBalance + :balance where mobileNumber = :mobile";
		MapSqlParameterSource param = new MapSqlParameterSource("balance", rechargeAmount).addValue("mobile", mobileNumber);
		return namedTemplate.update(query, param);
		
	}

	class AccountMapper implements RowMapper<Account>
	{

		@Override
		public Account mapRow(ResultSet rs, int rowNum) throws SQLException {
			Account acc = new Account();
			acc.setAccountType(rs.getString("accountType"));
			acc.setCustomerName(rs.getString("customerName"));
			acc.setAccountBalance(rs.getLong("accountBalance"));
			acc.setMobileNumber(rs.getString("mobileNumber"));
			return acc;
		}
		
	}
	
}

	
