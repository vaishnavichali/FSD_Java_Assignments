import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { WeeklyChart } from '../weekly-chart';

@Injectable({
  providedIn: 'root'
})
export class WeeklyChartServiceService {
 userArray : WeeklyChart[];
 element : WeeklyChart;
  constructor(private http: HttpClient) { }
  sendService(model: WeeklyChart[]) {  
    console.log("Inside service method")
    let url = "http://localhost:8080/charts";
    this.http.get(url).subscribe(
      res => {
       JSON.parse(JSON.stringify(res)).forEach(element => {
         this.userArray.push(element);
       });
        console.log(res); 
      }, err => {
        alert("Unknown Error Occurred");
      }
    );
  }
}
