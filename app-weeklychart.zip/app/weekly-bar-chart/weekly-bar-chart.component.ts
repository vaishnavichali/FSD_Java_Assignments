import { Component, OnInit } from '@angular/core';
import { WeeklyChartServiceService } from './weekly-chart-service.service';
import { WeeklyChart } from '../weekly-chart';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-weekly-bar-chart',
  templateUrl: './weekly-bar-chart.component.html',
  styleUrls: ['./weekly-bar-chart.component.css']
}) 
export class WeeklyBarChartComponent implements OnInit {
   result : WeeklyChart[];
   userArray = new Array();
  // userArray : Array<WeeklyChart>;
  // result = new Array<WeeklyChart>(); 
//  constructor(private service : WeeklyChartServiceService) { }

constructor(private http: HttpClient) { }
  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true
  };

  public barChartLabels;// = ["Mon", 'Tue', 'Wed', 'Thurs', 'Fri', 'Sat', 'Sun'];
  public barChartType = 'bar';
  public barChartLegend = true;
  public series1 = [];
  public series2 = [];
  public barChartData = [
    {data: this.series1, label: 'Recommended'},
    {data: this.series2, label: 'Achieved'}
  ];
  ngOnInit() {
  }

  drawWeeklyChart(): void{
    
  //  console.log("inside drawWeeklyChart method");
  //  this.service.sendService(this.result);    
 //   console.log(this.result);
 //sendService(model: WeeklyChart[]) {  
 // console.log("Inside service method")
  let url = "http://localhost:8080/charts";
  this.http.get(url).subscribe(
    res => {
     JSON.parse(JSON.stringify(res)).forEach(element => {
       this.userArray.push(element);
     });
     // console.log(this.barChartData);
      console.log(res); 
      
     // console.log(this.userArray);
   //  let arr : WeeklyChart = WeeklyChart(res);
    this.barChartLabels  = makeArray(res, 'day');
   console.log(this.barChartLabels);
  var values = makeArray(res, 'calories_burnt');
   console.log(values);
   this.series1 = values;
   this.series2 = values;
  // this.barChartData['data']=this.series1;
   console.log(this.series1);
  // console.log(this.barChartData['data']); //undefined
  // console.log(this.barChartData[1].data); //seems to work
  this.barChartData[0].data = this.series1;
  this.barChartData[1].data = this.series2;
    }, err => {
      alert("Unknown Error Occurred");
    }
  );
 // var labels  = makeArray(res, 'day');
//console.log(labels);

function makeArray(data , key) {
  return data.map(function(arr) {
    return  arr[key];
  });
}
 
  }

}
