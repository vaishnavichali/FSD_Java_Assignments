import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WeeklyBarChartComponent } from './weekly-bar-chart.component';

describe('WeeklyBarChartComponent', () => {
  let component: WeeklyBarChartComponent;
  let fixture: ComponentFixture<WeeklyBarChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WeeklyBarChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WeeklyBarChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
