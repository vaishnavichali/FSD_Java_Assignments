import { TestBed } from '@angular/core/testing';

import { WeeklyChartServiceService } from './weekly-chart-service.service';

describe('WeeklyChartServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WeeklyChartServiceService = TestBed.get(WeeklyChartServiceService);
    expect(service).toBeTruthy();
  });
});
