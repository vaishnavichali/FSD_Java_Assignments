export class WeeklyChart {
    constructor(
        public day : string,
        public calories_burnt: number
      ) { console.log("Constructor called");
     }
    toWeeklyChart(obj :Object)
    {
       
    }

} 
