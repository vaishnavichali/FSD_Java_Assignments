import { WeeklyChart } from './weekly-chart';

describe('WeeklyChart', () => {
  it('should create an instance', () => {
    expect(new WeeklyChart()).toBeTruthy();
  });
});
