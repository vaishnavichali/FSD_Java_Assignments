package com.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.model.CaloriesWeekly;
import com.demo.repository.WeeklyChartRepository;

@Service
public class WeeklyChartService {
	
	@Autowired
	WeeklyChartRepository repo;

	public Iterable<CaloriesWeekly> getAllCharts() {
		
		return repo.findAll();
	}

}
