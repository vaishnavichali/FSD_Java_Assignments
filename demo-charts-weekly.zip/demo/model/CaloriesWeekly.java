package com.demo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CaloriesWeekly {
	
	@Id
	private String day;
	private int calories_burnt;
	
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public int getCalories_burnt() {
		return calories_burnt;
	}
	public void setCalories_burnt(int calories_burnt) {
		this.calories_burnt = calories_burnt;
	}
	public CaloriesWeekly(String day, int calories_burnt) {
		
		this.day = day;
		this.calories_burnt = calories_burnt;
	}
	public CaloriesWeekly() {
			}
	
	

}
