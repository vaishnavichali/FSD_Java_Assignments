package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.CaloriesWeekly;
import com.demo.service.WeeklyChartService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class WeeklyChartController {
	
	@Autowired
	WeeklyChartService service;
	
	@RequestMapping("/charts")
	Iterable<CaloriesWeekly> getAllCharts()
	{
		return service.getAllCharts();
	}
	

}
