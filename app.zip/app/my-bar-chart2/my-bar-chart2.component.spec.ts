import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyBarChart2Component } from './my-bar-chart2.component';

describe('MyBarChart2Component', () => {
  let component: MyBarChart2Component;
  let fixture: ComponentFixture<MyBarChart2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyBarChart2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyBarChart2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
