import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChartsModule } from 'ng2-charts';
import { MyBarChartComponent } from './my-bar-chart/my-bar-chart.component';
import { Routes, RouterModule } from '@angular/router';
import { MyBarChart1Component } from './my-bar-chart1/my-bar-chart1.component';
import { MyBarChart2Component } from './my-bar-chart2/my-bar-chart2.component';

const routes: Routes = [
  {path: 'bar-chart', component: MyBarChartComponent},
  {path: 'bar-chart1', component: MyBarChart1Component},
  {path: 'bar-chart2', component: MyBarChart2Component},
 // {path: 'doughnut-chart', component: MyDoughnutChartComponent},
  //{path: 'radar-chart', component: MyRadarChartComponent},
 // {path: 'pie-chart', component: MyPieChartComponent},
 // {path: '**', component: MyBarChartComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    MyBarChartComponent,
    MyBarChart1Component,
    MyBarChart2Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,

    
      RouterModule.forRoot(routes),
      ChartsModule
    


  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
